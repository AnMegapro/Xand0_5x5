
import pygame
from pygame import font
from random import randint as rnd
import os

pygame.init()

WIDTH:int = 1000
HEIGHT:int = 1000
size = (WIDTH, HEIGHT)
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()
done = False

cubes = pygame.sprite.Group()
move=0
a=[["_","_","_","_","_"],["_","_","_","_","_"],["_","_","_","_","_"],["_","_","_","_","_"],["_","_","_","_","_"]]
class Element():
    def __init__( self,ir, zr):
        
        x = ir*100
        y = zr*100
        self.i2=ir
        self.z2=zr
        print(self.z2)
        a=rnd(0,2)
        
        my_image_path = os.path.join('W.jpg')
        

        my_image = pygame.image.load(my_image_path).convert_alpha()
        
        self.image = my_image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.col=0
    def update(self):
        global move
        global a
        global done
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.x == (event.pos[0]//100)*100 and self.rect.y == (event.pos[1]//100)*100:
                
                if move==0 and a[self.z2][self.i2]=="_":
                    
                    
                    my_image_path = os.path.join('X.jpg')
                    move=1
                    a[self.z2][self.i2]="x"
                    my_image = pygame.image.load(my_image_path).convert_alpha()
                    self.image = my_image
                elif move==1and a[self.z2][self.i2]=="_":
                    my_image_path = os.path.join('0.jpg')
                    move=0
                    a[self.z2][self.i2]="0"
                
                    my_image = pygame.image.load(my_image_path).convert_alpha()
                    self.image = my_image
                
                for z in range(5):
                    end=True
                    for x in range(4):
                        if a[z][x]!=a[z][x+1]:
                            end=False
                    if end == True :
                        if a[z][x]=="x":
                            done=True
                            print("X won this game!")
                        elif a[z][x]=="0":
                            done=True
                            print("0 won this game!")
                for x in range(5):
                    end=True
                    for z in range(4):
                        if a[z][x]!=a[z+1][x]:
                            end=False
                    if end == True :
                        if a[z][x]=="x":
                            done=True
                            print("X won this game!")

                        elif a[z][x]=="0":
                            done=True
                            print("0 won this game!")
                if a[1][1]==a[2][2]==a[3][3]==a[4][4]==a[0][0]=="x":
                    done=True
                    print("X won this game!")
                elif a[1][1]==a[2][2]==a[3][3]==a[4][4]==a[0][0]=="0":
                    done=True
                    print("0 won this game!")
                elif a[0][0]==a[1][1]==a[2][2]==a[3][3]==a[4][4]=="x":
                    done=True
                    print("X won this game!")
                elif a[0][4]==a[1][3]==a[2][2]==a[3][1]==a[4][0]=="0":
                    done=True
                    print("0 won this game!")
                            
        
for z in range(5):
    for i in range(5):
        
        
        
        cube = Element(i,z)
        cubes.add_internal(cube)
        

while not done:
    clock.tick(10)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            print(event.pos, event.button)
            pass
        


    screen.fill(pygame.Color('black'))
    cubes.update()
   
    cubes.draw(screen)
    pygame.display.flip()
pygame.quit()
